CREATE FUNCTION bit_length(bytea)
  RETURNS integer
IMMUTABLE
STRICT
COST 1
LANGUAGE SQL
AS $$
select pg_catalog.octet_length($1) * 8
$$;

